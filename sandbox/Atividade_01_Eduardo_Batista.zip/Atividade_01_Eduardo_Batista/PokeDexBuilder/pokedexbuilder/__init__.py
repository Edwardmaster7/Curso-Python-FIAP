from .models import Pokemon, Pokedex

__all__ = ['Pokemon', 'Pokedex']
